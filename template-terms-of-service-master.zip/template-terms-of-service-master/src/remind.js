// run this file periodically to find users who have not accepted the ToS
const onboard = require('./onboard');

onboard.remind();
